if __name__ == '__main__':
    import sys
    args = sys.argv
    installer_file = args[2]
    installer_options = '/silent'
    
    import subprocess
    installer_process = subprocess.Popen([installer_file, installer_options])
    installer_process.wait()
    
    import os
    for i in range(1, len(args)):
        if os.path.exists(args[i]):
            os.remove(args[i])
            
    subprocess.Popen(['Network Folders.exe'])
    sys.exit(0)